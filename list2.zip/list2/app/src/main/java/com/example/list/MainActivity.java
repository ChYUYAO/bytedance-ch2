package com.example.list;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvl;
    private List<mList> mlist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mList i1 = new mList(1, "敬礼我的超级英雄", 548583);
        mlist.add(i1);
        mList i2 = new mList(2, "我们不一样YOUNG", 504189);
        mlist.add(i2);
        mList i3 = new mList(3, "珍\"eye\"每一天", 486636);
        mlist.add(i3);
        mList i4 = new mList(4, "请平安出行", 301982);
        mlist.add(i4);
        mList i5 = new mList(5, "现在是怀旧时间", 301928);
        mlist.add(i5);
        mList i6 = new mList(6, "纸短情长", 299192);
        mlist.add(i6);
        mList i7 = new mList(7, "我们一起学猫叫", 291049);
        mlist.add(i7);

        rvl = findViewById(R.id.rvl);
        rvl.setLayoutManager(new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL));

        mAdapter madapter = new mAdapter();
        madapter.set(mlist);

        rvl.setAdapter(madapter);
        madapter.notifyDataSetChanged();
    }
}
