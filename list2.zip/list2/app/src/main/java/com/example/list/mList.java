package com.example.list;

public class mList {
    private int id;
    private String title;
    private int hotValue;

    public mList(int id, String title, int hotValue){
        this.id = id;
        this.title = title;
        this.hotValue = hotValue;
    }

    public int GetHotValue() {
        return hotValue;
    }
    public int GetId() {
        return id;
    }
    public String GetTitle() {
        return title;
    }
}
