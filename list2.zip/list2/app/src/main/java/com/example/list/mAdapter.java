package com.example.list;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class mAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<mList> itemList;

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int i) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.m_list,parent,false);
            return new mViewHolder(view);
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i) {
        ((mViewHolder)viewHolder).bind(itemList, itemList.get(i), i);
    }

    public int getItemCount() {
        return itemList.size();
    }

    public void set(List<mList> list){
            itemList = list;
    }
}
