package com.example.list;

import android.graphics.Color;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class mViewHolder extends RecyclerView.ViewHolder {
    public TextView title;
    public TextView id;
    public TextView hotValue;
    public List<mList> itemL;

    private int position;

    public mViewHolder(@NonNull final View itemView) {
        super(itemView);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(itemView.getContext(), itemL.get(position).GetTitle(),Toast.LENGTH_SHORT).show();
            }
        });
        title = itemView.findViewById(R.id.titleName);
        id = itemView.findViewById(R.id.itemID);
        hotValue = itemView.findViewById(R.id.hotValue);
    }

    public void bind(List<mList> itemL, mList mlist, int position) {
        title.setText(mlist.GetTitle());
        hotValue.setText(mlist.GetHotValue() + "");
        id.setText(mlist.GetId() + ".");
        if(position>=3) {
            id.setTextColor(Color.parseColor("#99FFFFFF"));
        }
        this.position = position;
        this.itemL = itemL;
    }
}
